const EditProfile = ()=>{
  return(
    <h2>EditProfile</h2>
  )
}
export default EditProfile;